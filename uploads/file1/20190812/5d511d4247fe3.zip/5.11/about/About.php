<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Request;


class About extends Base
{
	
	
    public function index()
    {
        $data = Db::name("company")->where(['id'=>1])->find();
        $this->assign('data', $data);
        return $this->fetch();
    }

    public function contact()
    {
        $data = Db::name("company")->where(['id'=>2])->find();
        $this->assign('data', $data);
        return $this->fetch();
    }

    public function words()
    {
		$user_id = session("member.id");

		$user_info = Db::name("member_user")->where("id=".$user_id)->find();
		$this->assign("user_info",$user_info);

        $data = Db::name('liuyan')->alias('a')
            ->order('a.create_time desc')
            ->join('member_user b','b.id=a.user_id','LEFT')
            ->paginate(10, false, ['query' => Request::instance()->param()]);
        if($this->request->isPost()){
            if(!session("member.id")){
                $this->success("请先登录系统","Index/home/register");
            }
            $post = $this->request->post("");
            $add_data['content'] = $post['content'];
            $add_data['user_id'] = session("member.id");
            $add_data['create_time'] = date("Y-m-d H:i:s");
            db("liuyan")->insert($add_data);
            $this->success("留言成功");
        }
        $this->assign('data', $data);
        return $this->fetch();

    }
}